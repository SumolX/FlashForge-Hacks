$(document).ready(function (){
	
	$("#home").bind('click',function(){
	  top.location.href="Home.html";
	})
	
});
